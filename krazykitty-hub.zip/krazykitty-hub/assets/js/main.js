/* =========================================================
   KITTYS//ECOSYSTEM — progressive enhancement only.
   The page is fully readable with JavaScript disabled.
   No third-party code, no network requests, no storage.
   ========================================================= */
"use strict";

(() => {
  const root = document.documentElement;
  root.classList.remove("no-js");
  root.classList.add("js");

  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
  let effectsOn = !reduceMotion.matches;

  /* ---------- 1. project filter ---------- */
  const filterButtons = document.querySelectorAll("[data-filter]");
  const projects = document.querySelectorAll(".project[data-status]");
  const groups = document.querySelectorAll(".group");
  const live = document.getElementById("filter-status");
  let lastAnnounced = "";

  function applyFilter(value) {
    let shown = 0;
    projects.forEach((card) => {
      const match = value === "all" || card.dataset.status === value;
      card.hidden = !match;
      if (match) shown += 1;
    });
    groups.forEach((group) => {
      group.hidden = !group.querySelector(".project:not([hidden])");
    });
    filterButtons.forEach((btn) =>
      btn.setAttribute("aria-pressed", String(btn.dataset.filter === value))
    );
    /* one polite status region; text changes only on a real transition */
    if (live) {
      const msg = `Showing ${shown} ${shown === 1 ? "project" : "projects"}${
        value === "all" ? "" : ` with status ${value}`
      }.`;
      if (msg !== lastAnnounced) {
        live.textContent = msg;
        lastAnnounced = msg;
      }
    }
  }
  filterButtons.forEach((btn) =>
    btn.addEventListener("click", () => applyFilter(btn.dataset.filter))
  );

  /* ---------- 2. nav highlight for the section in view ---------- */
  const links = [...document.querySelectorAll(".nav a[href^='#']")];
  const targets = links
    .map((a) => document.querySelector(a.getAttribute("href")))
    .filter(Boolean);

  if ("IntersectionObserver" in window && targets.length) {
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          links.forEach((a) => {
            if (a.getAttribute("href") === `#${entry.target.id}`) {
              a.setAttribute("aria-current", "true");
            } else {
              a.removeAttribute("aria-current");
            }
          });
        });
      },
      { rootMargin: "-45% 0px -50% 0px" }
    );
    targets.forEach((t) => io.observe(t));
  }

  /* ---------- 3. decorative boot sequence (line reveal, no layout shift) ---------- */
  const bootLines = document.querySelectorAll(".terminal-line[data-boot]");
  if (bootLines.length && effectsOn) {
    bootLines.forEach((l) => l.classList.add("is-hidden"));
    bootLines.forEach((line, i) =>
      window.setTimeout(() => line.classList.remove("is-hidden"), 350 + i * 320)
    );
  }

  /* ---------- 4. background particles ---------- */
  const canvas = document.getElementById("particles");
  const ctx = canvas && canvas.getContext ? canvas.getContext("2d") : null;
  const COLOURS = ["#c084fc", "#9333ea", "#f0abfc"];
  let w = 0, h = 0, dpr = 1, particles = [], raf = 0;

  const rand = (min, max) => Math.random() * (max - min) + min;
  const makeParticle = () => ({
    x: rand(0, w), y: rand(0, h), r: rand(0.4, 1.5),
    vx: rand(-0.12, 0.12), vy: rand(-0.12, 0.12), a: rand(0.1, 0.5),
    c: COLOURS[Math.floor(Math.random() * COLOURS.length)],
  });

  function resize() {
    if (!canvas || !ctx) return;
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    w = window.innerWidth; h = window.innerHeight;
    canvas.width = Math.floor(w * dpr);
    canvas.height = Math.floor(h * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const count = Math.min(Math.floor((w * h) / 18000), 90);
    particles = Array.from({ length: count }, makeParticle);
  }

  function frame() {
    ctx.clearRect(0, 0, w, h);
    for (const p of particles) {
      p.x += p.vx; p.y += p.vy;
      if (p.x < 0) p.x = w; else if (p.x > w) p.x = 0;
      if (p.y < 0) p.y = h; else if (p.y > h) p.y = 0;
      ctx.globalAlpha = p.a;
      ctx.fillStyle = p.c;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fill();
    }
    raf = window.requestAnimationFrame(frame);
  }
  const start = () => { if (ctx && effectsOn && !raf && !document.hidden) raf = window.requestAnimationFrame(frame); };
  const stop = () => { window.cancelAnimationFrame(raf); raf = 0; if (ctx) ctx.clearRect(0, 0, w, h); };

  let resizeTimer = 0;
  window.addEventListener("resize", () => {
    window.clearTimeout(resizeTimer);
    resizeTimer = window.setTimeout(resize, 150);
  }, { passive: true });
  document.addEventListener("visibilitychange", () => (document.hidden ? stop() : start()));

  /* ---------- 5. EFFECTS toggle (user-controlled pause) ---------- */
  const fx = document.getElementById("fx-toggle");

  function setEffects(on) {
    effectsOn = on;
    if (on) root.removeAttribute("data-motion"); else root.setAttribute("data-motion", "off");
    if (fx) fx.setAttribute("aria-pressed", String(on));
    if (on) start(); else stop();
  }
  if (fx) fx.addEventListener("click", () => setEffects(!effectsOn));

  reduceMotion.addEventListener("change", (e) => setEffects(!e.matches));

  resize();
  setEffects(effectsOn);
})();
