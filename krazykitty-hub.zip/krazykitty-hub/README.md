# KITTYS//ECOSYSTEM

Portfolio hub for **krazykitty.dev**. Static HTML, CSS and vanilla JS: no framework, no build step, no third-party requests.

## Structure

```text
index.html
assets/
  css/   kk-tokens.css  fonts.css  site.css
  js/    main.js
  img/   avatar.webp  hero-wallpaper.webp  og-card.jpg  banner-discord.webp  favicon.svg
  fonts/ Orbitron, Inter, Share Tech Mono (latin woff2) + OFL licence files
```

Preview locally:

```bash
python3 -m http.server 8080   # then open http://127.0.0.1:8080/
```

## Design-system pin

`assets/css/kk-tokens.css` is a verbatim copy of `reference-css/kk-tokens.css` from **KrazyKitty Design System v0.1.0** (commit `e5d2d1b`). Do not edit it by hand; re-copy it when the design system releases a new version and update the footer line in `index.html`.

`site.css` only aliases tokens (`--lead`, `--fill`, `--seasoning`); it introduces no new colours.

**Open palette question:** the brief hexes (`#8B5CF6`, `#A855F7`, `#D8B4FE`) differ from the design-system tokens (accent `#d946ef`, violet `#c084fc`). The hub follows the tokens. To change the look, change the token layer in the design system first, then re-copy.

## Fonts

Self-hosted from `@fontsource` packages (SIL OFL), latin subset only.

| Font | Package | Version |
| --- | --- | --- |
| Orbitron (variable) | `@fontsource-variable/orbitron` | 5.3.0 |
| Inter (variable) | `@fontsource-variable/inter` | 5.3.0 |
| Share Tech Mono | `@fontsource/share-tech-mono` | 5.3.0 |

## Adding a project card

1. Copy an existing `<article class="project" data-status="…">` into the matching `<div class="group">` (running, building, planned).
2. Set `data-status` to `running`, `building` or `planned` (the filter reads this).
3. Give it the next `PRJ-nn` code and an `id` if other cards link to it.
4. Fill **CURRENT STATE** and **NEXT GATE** in the `<details>`.
5. Add a `project-basis` line: `BASIS: <evidence> · <date> · SOURCE: private|public`. Only link a repo if it is public.

## Status vocabulary

| Tag | Meaning |
| --- | --- |
| RUNNING | Operating when last checked (dated, manual) |
| BUILDING | Under active development |
| PLANNED / PROPOSED | Designed or proposed; nothing built |
| DEMO DATA | UI shows mock data |
| HANDS-ON / LEARNING / EXPLORING | Lab experience levels |

Reserved status colours (ok/warn/danger/info) are for **measured readings only** and are deliberately unused for lifecycle tags. The page states that it is not live telemetry.

## Content rules

No credentials, Discord IDs or invites, private IPs, hardware identifiers, private letters or legal name. Private repositories are described but not linked. Only `kittylm` is linked (public, Apache-2.0).

## Deployment (example Caddyfile)

Send the CSP as a **header**, not a `<meta>` tag: `frame-ancestors` only works as a header, and `'self'` can misbehave under `file://`.

```caddy
krazykitty.dev {
	root * /srv/krazykitty-hub
	file_server
	encode zstd gzip
	header {
		Content-Security-Policy "default-src 'none'; img-src 'self'; style-src 'self'; script-src 'self'; font-src 'self'; connect-src 'none'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'"
		X-Content-Type-Options nosniff
		Referrer-Policy strict-origin-when-cross-origin
		Strict-Transport-Security "max-age=31536000"
		Permissions-Policy "camera=(), microphone=(), geolocation=()"
	}
	@static path /assets/*
	header @static Cache-Control "public, max-age=31536000, immutable"
}
www.krazykitty.dev {
	redir https://krazykitty.dev{uri} permanent
}
```

Canonical URL is `https://krazykitty.dev/`. Your GitHub profile currently links `https://www.krazykitty.dev`; the redirect above covers it, or switch the canonical to www.

Caveat: `immutable` caching on unversioned filenames means changed assets will not refresh. Rename files (or add `?v=`) when you change them, or drop `immutable`.

## Verification status

| Check | Result |
| --- | --- |
| Served with strict CSP (headless Chromium, 1440 and 390 px) | No console errors or CSP violations; 11 requests, all same-origin |
| Horizontal overflow | None at either width |
| Filter buttons, EFFECTS toggle, `<details>` | Behave as intended (scripted) |
| axe-core 4.10.2 (WCAG 2.0–2.2 A/AA + best-practice) | 0 violations; colour contrast over images reported "incomplete" |
| Text contrast, pixel-sampled over rendered backgrounds | 73 text styles, lowest 4.80:1 (AA needs 4.5:1) |
| Gradient title, button borders, focus rings | **Not measured** |
| Screen reader (NVDA/VoiceOver), keyboard walk-through by a person | **Not done** |
| Real-device mobile, Safari, Firefox | **Not done** |
| Automated scans | Cannot establish full WCAG compliance |
